<?php
header("Content-Type: application/json");
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $result = $conn->query("SELECT * FROM rooms");
        $rooms = [];
        while ($row = $result->fetch_assoc()) {
            $row['available'] = (bool)$row['available'];
            $row['discounted'] = (bool)$row['discounted'];
            $row['bookedDates'] = $row['bookedDates'] ? json_decode($row['bookedDates']) : [];
            $rooms[] = $row;
        }
        echo json_encode($rooms);
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("INSERT INTO rooms (name, type, price, available, discounted, guests, rating, image, description, bookedDates) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "ssiiiidsss",
            $data['name'], $data['type'], $data['price'],
            $data['available'] ? 1 : 0, $data['discounted'] ? 1 : 0,
            $data['guests'], $data['rating'],
            $data['image'], $data['description'],
            json_encode($data['bookedDates'] ?? [])
        );
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Cannot save room']);
        }
        break;

    case 'PUT':
        parse_str(file_get_contents("php://input"), $_PUT);
        $data = json_decode(file_get_contents("php://input"), true);
        $id = $_GET['id'] ?? 0;
        $stmt = $conn->prepare("UPDATE rooms SET name=?, type=?, price=?, available=?, discounted=?, guests=?, rating=?, image=?, description=?, bookedDates=? WHERE id=?");
        $stmt->bind_param(
            "ssiiiidsssi",
            $data['name'], $data['type'], $data['price'],
            $data['available'] ? 1 : 0, $data['discounted'] ? 1 : 0,
            $data['guests'], $data['rating'],
            $data['image'], $data['description'],
            json_encode($data['bookedDates'] ?? []), $id
        );
        $ok = $stmt->execute();
        echo json_encode(['success' => $ok]);
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? 0;
        $stmt = $conn->prepare("DELETE FROM rooms WHERE id = ?");
        $stmt->bind_param("i", $id);
        $ok = $stmt->execute();
        echo json_encode(['success' => $ok]);
        break;

    case 'PATCH': // бронирование
        $id = $_GET['id'] ?? 0;
        $data = json_decode(file_get_contents("php://input"), true);
        $newDates = $data['newDates'] ?? [];

        $result = $conn->query("SELECT bookedDates FROM rooms WHERE id = $id");
        if ($result->num_rows === 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Room not found']);
            exit;
        }

        $row = $result->fetch_assoc();
        $booked = json_decode($row['bookedDates'], true) ?? [];
        $merged = array_unique(array_merge($booked, $newDates));

        $stmt = $conn->prepare("UPDATE rooms SET bookedDates = ?, available = 0 WHERE id = ?");
        $jsonDates = json_encode($merged);
        $stmt->bind_param("si", $jsonDates, $id);
        $ok = $stmt->execute();
        echo json_encode(['success' => $ok, 'bookedDates' => $merged, 'available' => 0]);
        break;
}
?>
